package com.doorcart.doorcart_android

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
